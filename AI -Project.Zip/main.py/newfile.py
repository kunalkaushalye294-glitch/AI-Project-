min.py
import os

def create_folder(folder_name):
    os.makedirs(folder_name, exist_ok=True)
    print(f"✅ Folder '{folder_name}' created successfully!")

def create_file(file_name, content=""):
    with open(file_name, "w") as f:
        f.write(content)
    print(f"📝 File '{file_name}' created with content.")

def delete_file(file_name):
    if os.path.exists(file_name):
        os.remove(file_name)
        print(f"🗑️ File '{file_name}' deleted!")
    else:
        print(f"⚠️ File '{file_name}' not found.")

def main():
    print("🤖 Welcome to AI Task Automation Agent")
    print("Type 'exit' to quit.\n")

    while True:
        command = input("Enter command: ").lower()

        if command == "exit":
            print("👋 Goodbye!")
            break
        elif "create folder" in command:
            name = command.replace("create folder", "").strip()
            create_folder(name)
        elif "create file" in command:
            name = command.replace("create file", "").strip()
            create_file(name)
        elif "delete file" in command:
            name = command.replace("delete file", "").strip()
            delete_file(name)
        else:
            print("⚙️ Unknown command.")

if __name__ == "__main__":
    main()